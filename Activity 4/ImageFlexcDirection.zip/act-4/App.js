import React from 'react';
import {StyleSheet, TextInput, View} from 'react-native';
import {SafeAreaView, SafeAreaProvider} from 'react-native-safe-area-context';
import Icon from 'react-native-vector-icons/FontAwesome';

const TextInputExample = () => {
  const [name, onChangeTextName] = React.useState('Name:');
  const [age, onChangeTextAge] = React.useState('Age:');
  const [address, onChangeTextAddress] = React.useState('Address:');
  const [school, onChangeTextSchool] = React.useState('School:');
  const [course, onChangeTextCourse] = React.useState('Course:');
  const [email, onChangeTextEmail] = React.useState('Email:');
  const [contactno, onChangeTextContactno] = React.useState('Contactno:');

  return (
    <SafeAreaProvider>
      <SafeAreaView>
        <View style={styles.inputContainer}>
          <Icon name="user" size={20} color="green" style={styles.iconOutside} />
          <View style={styles.inputBox}>
            <TextInput
              style={styles.input}
              onChangeText={onChangeTextName}
              value={name}
            />
          </View>
        </View>
        <View style={styles.inputContainer}>
          <Icon name="calendar" size={20} color="green" style={styles.iconOutside} />
          <View style={styles.inputBox}>
            <TextInput
              style={styles.input}
              onChangeText={onChangeTextAge}
              value={age}
            />
          </View>
        </View>
        <View style={styles.inputContainer}>
          <Icon name="home" size={20} color="green" style={styles.iconOutside} />
          <View style={styles.inputBox}>
            <TextInput
              style={styles.input}
              onChangeText={onChangeTextAddress}
              value={address}
            />
          </View>
        </View>
        <View style={styles.inputContainer}>
          <Icon name="university" size={20} color="green" style={styles.iconOutside} />
          <View style={styles.inputBox}>
            <TextInput
              style={styles.input}
              onChangeText={onChangeTextSchool}
              value={school}
            />
          </View>
        </View>
        <View style={styles.inputContainer}>
          <Icon name="book" size={20} color="green" style={styles.iconOutside} />
          <View style={styles.inputBox}>
            <TextInput
              style={styles.input}
              onChangeText={onChangeTextCourse}
              value={course}
            />
          </View>
        </View>
        <View style={styles.inputContainer}>
          <Icon name="envelope" size={20} color="green" style={styles.iconOutside} />
          <View style={styles.inputBox}>
            <TextInput
              style={styles.input}
              onChangeText={onChangeTextEmail}
              value={email}
            />
          </View>
        </View>
        <View style={styles.inputContainer}>
          <Icon name="phone" size={20} color="green" style={styles.iconOutside} />
          <View style={styles.inputBox}>
            <TextInput
              style={styles.input}
              onChangeText={onChangeTextContactno}
              value={contactno}
            />
          </View>
        </View>
        <View style={styles.inputContainer}>
          <Icon name="info-circle" size={20} color="green" style={styles.iconOutside} />
          <View style={styles.inputBox}>
            <MultilineTextInputExample />
          </View>
        </View>
      </SafeAreaView>
    </SafeAreaProvider>
  );
};

const MultilineTextInputExample = () => {
  const [aboutme, onChangeTextAboutme] = React.useState('About me:');

  return (
    <SafeAreaProvider>
      <SafeAreaView
        style={[
          multilineStyles.container,
          {
            backgroundColor: aboutme,
          },
        ]}>
        <TextInput
          editable
          multiline
          numberOfLines={4}
          maxLength={40}
          onChangeText={text => onChangeTextAboutme(text)}
          value={aboutme}
          style={multilineStyles.textInput}
        />
      </SafeAreaView>
    </SafeAreaProvider>
  );
};

const styles = StyleSheet.create({
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    margin: 10,
  },
  inputBox: {
    flex: 1,
    borderWidth: 1,
    padding: 10,
  },
  input: {
    height: 40,
  },
  iconOutside: {
    marginRight: 10,
  },
});

const multilineStyles = StyleSheet.create({
  container: {
    borderBottomColor: '#000',
    borderTopWidth: 1,
    borderBottomWidth: 1,
  },
  textInput: {
    padding: 10,
    margin: 1,
    borderWidth: 0,
  },
});

export default TextInputExample;
